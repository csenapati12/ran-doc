<h1>
OPTIMO Annotation Background Image
    <h3>All the videos captured need  to save one image</h3>
</h1>



