from flask import url_for
from optimo.models.models import Video, Annotation
from sqlalchemy import desc


def _save_dummy_video():
    video = Video(
        record_time="startTime",
        stop_time="endTime",
        fps=29,
        video_name="testVideo.mp4",
        anno_sign=0,
        user_id=1,
    )
    video.save()


def _save_annotation_new(testapp, **kwargs):
    _save_dummy_video()
    return testapp.post_json(
        url_for("annotation_views.saveAnnoInfo"),
        {
            "annoInfo": [
                {
                    "annoBatch": 1,
                    "annoID": 1,
                    "endTime": "endTime",
                    "startTime": "startTime",
                    "task": "testTask1",
                    "videoID": 1,
                    "left": "0px",
                    "width": "68.4px",
                }
            ],
            "saveAs": True,
        },
        **kwargs
    )


def _save_annotation_change(testapp, **kwargs):
    return testapp.post_json(
        url_for("annotation_views.saveAnnoInfo"),
        {
            "annoInfo": [
                {
                    "annoBatch": 1,
                    "annoID": 1,
                    "endTime": "endTime",
                    "startTime": "startTime",
                    "task": "testTask2",
                    "videoID": 1,
                    "left": "0px",
                    "width": "68.4px",
                }
            ],
            "saveAs": False,
        },
        **kwargs
    )


class TestAnnotation:
    def test_save_annotation_if_new(self, testapp):
        resp = _save_annotation_new(testapp)
        annotation_list = (
            Annotation.query.filter_by(video_id=1)
            .order_by(desc(Annotation.annotation_batch))
            .limit(1)
            .all()
        )

        assert resp.status_code == 200
        assert annotation_list[0].video_id == 1
        assert annotation_list[0].annotation_batch == 1
        assert annotation_list[0].start_time == "startTime"
        assert annotation_list[0].end_time == "endTime"
        assert annotation_list[0].task == "testTask1"

    def test_save_annotation_if_change(self, testapp):
        _save_annotation_new(testapp)

        resp = _save_annotation_change(testapp)
        annotation_list = (
            Annotation.query.filter_by(video_id=1)
            .order_by(desc(Annotation.annotation_batch))
            .limit(1)
            .all()
        )

        assert resp.status_code == 200
        assert annotation_list[0].video_id == 1
        assert annotation_list[0].annotation_batch == 1
        assert annotation_list[0].start_time == "startTime"
        assert annotation_list[0].end_time == "endTime"
        assert annotation_list[0].task == "testTask2"

    def test_get_annotation_boxes(self, testapp):
        _save_annotation_new(testapp)

        resp = testapp.get(
            url_for("annotation_views.getAnnoBoxes", videoID=1, batch_id=1),
        )
        contents = resp.json

        assert resp.status_code == 200
        assert len(contents) == 1
        assert contents[0]["videoID"] == 1
        assert contents[0]["annoBatch"] == 1
        assert contents[0]["annoID"] == 1
        assert contents[0]["startTime"] == "startTime"
        assert contents[0]["endTime"] == "endTime"
        assert contents[0]["task"] == "testTask1"

    def test_get_annotation_batches(self, testapp):
        _save_annotation_new(testapp)

        resp = testapp.get(
            url_for("annotation_views.getAnnotationBatches", video_id=1),
        )
        contents = resp.json

        assert resp.status_code == 200
        assert len(contents) == 1
        assert contents[0]["id"] == 1
        assert contents[0]["name"] == "Version 1"

    def test_delete_annotation_batch(self, testapp):
        _save_annotation_new(testapp)

        resp = testapp.delete(
            url_for("annotation_views.deleteAnnotationBatches", videoID=1, batch_id=1),
        )
        annotation_list = Annotation.query.filter_by(video_id=1).all()

        assert resp.status_code == 200
        assert len(annotation_list) == 0

    def test_get_unique_label_name(self, testapp):
        _save_annotation_new(testapp)

        resp = testapp.post_json(
            url_for("annotation_views.getUniqueLabelNames"),
            {"video_id": [1], "annotationBatchId": [1]},
        )
        contents = resp.json

        assert resp.status_code == 200
        assert len(contents) == 1
        assert contents[0]["label"] == "testTask1"

    def test_annotation_count(self, testapp):
        _save_annotation_new(testapp)

        resp = testapp.get(
            url_for("annotation_views.getAnnotationsCount"),
        )
        contents = resp.json

        assert resp.status_code == 200
        assert len(contents) == 1
