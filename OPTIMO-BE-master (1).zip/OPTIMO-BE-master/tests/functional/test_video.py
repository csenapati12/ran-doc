from flask import url_for
import cv2
import os
import time
from optimo.settings import Config
from optimo.models.models import Video

PROJECT_ROOT = Config.PROJECT_ROOT
DATAPATH = Config.DATA_PATH
temporaryVideosPath = os.path.abspath(os.path.join(DATAPATH, "temporary_videos"))
originalVideosPath = os.path.abspath(os.path.join(DATAPATH, "original_videos"))
currentVideoName = os.path.abspath(os.path.join(originalVideosPath, "testVideo.mp4"))


def save_dummy_video():
    video = Video(
        record_time="startTime",
        stop_time="endTime",
        fps=29.000049,
        video_name="testVideo.mp4",
        anno_sign=0,
        user_id=1,
    )
    video.save()
    video = cv2.VideoCapture(0)
    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    writer = cv2.VideoWriter(
        currentVideoName, cv2.VideoWriter_fourcc(*"mp4v"), 20, (width, height)
    )
    t_end = time.time() + 0.1
    while time.time() < t_end:
        ret, frame = video.read()
        writer.write(frame)
        cv2.imshow("frame", frame)
    video.release()
    writer.release()
    cv2.destroyAllWindows()


def delete_dummy_video():
    videoPath = os.path.abspath(os.path.join(originalVideosPath, "testVideo.mp4"))
    querriedVideo = Video.query.filter_by(video_name="testVideo.mp4").first()
    os.remove(videoPath)
    querriedVideo.delete()


class TestVideoService:
    def test_streaming():
        """TODO Add logic here"""

    def test_recording(self, testapp):
        # test for startRecord
        resp = testapp.post_json(
            url_for("video_handling_views.startRecord"),
            {
                "startRecord": "True",
                "stopRecord": "False",
                "videoName": "testVideo.mp4",
            },
        )

        assert resp.status_code == 200

        # test for stopRecord
        resp = testapp.post_json(
            url_for("video_handling_views.stopRecord"),
            {
                "startRecord": "False",
                "stopRecord": "True",
                "videoName": "testVideo.mp4",
            },
        )

        assert resp.status_code == 200

    def test_save_video(self, testapp):

        resp = testapp.post_json(
            url_for("video_handling_views.saveVideoInfo"),
            [{"start": "startTime", "end": "endTime", "videoName": "momo"}],
        )

        assert resp.status_code == 204

    def test_upload_video():
        """TODO Add logic here"""

    def test_video_count(self, testapp):
        resp = testapp.get(
            url_for("video_handling_views.getVideoCount"),
        )
        contentsBefore = list(resp.json.values())

        assert resp.status_code == 200

        save_dummy_video()

        resp = testapp.get(
            url_for("video_handling_views.getVideoCount"),
        )
        contentsAfter = list(resp.json.values())
        delete_dummy_video()

        assert resp.status_code == 200
        assert contentsAfter[0] == contentsBefore[0] + 1

    def test_video_sign(self, testapp):
        resp = testapp.get(
            url_for("video_handling_views.getVideoSigns"),
        )
        contentsBefore = list(resp.json.values())

        assert resp.status_code == 200

        save_dummy_video()

        resp = testapp.get(
            url_for("video_handling_views.getVideoSigns"),
        )
        contentsAfter = list(resp.json.values())
        delete_dummy_video()

        assert resp.status_code == 200
        assert contentsAfter[0] == contentsBefore[0]
        assert contentsAfter[1] == contentsBefore[1]
        assert contentsAfter[2] == contentsBefore[2] + 1

    def test_show_video(self, testapp):
        save_dummy_video()
        resp = testapp.get(
            url_for("video_handling_views.showVideo", file_name="testVideo.mp4"),
        )
        delete_dummy_video()

        assert resp.status_code == 200

    def test_get_video(self, testapp):
        # test for originalVideos
        resp = testapp.get(
            url_for("video_handling_views.getOriVideoInfo"),
        )

        contentsBefore = resp.json
        assert resp.status_code == 200

        save_dummy_video()
        resp = testapp.get(
            url_for("video_handling_views.getOriVideoInfo"),
        )
        delete_dummy_video()
        contentsAfter = resp.json

        assert len(contentsAfter) == len(contentsBefore) + 1
        assert resp.status_code == 200

        # test for annotatedVideos
        resp = testapp.get(
            url_for("video_handling_views.getAnnoVideoInfo"),
        )
        contentsBefore = resp.json

        assert resp.status_code == 200

        save_dummy_video()
        resp = testapp.get(
            url_for("video_handling_views.getAnnoVideoInfo"),
        )
        delete_dummy_video()
        contentsAfter = resp.json

        assert len(contentsAfter) == len(contentsBefore)
        assert resp.status_code == 200

    def test_delete_video(self, testapp):
        save_dummy_video()
        resp = testapp.post_json(
            url_for("video_handling_views.delVideo"), {"videoName": "testVideo.mp4"}
        )

        assert resp.status_code == 200
        assert os.path.exists(currentVideoName) == False
