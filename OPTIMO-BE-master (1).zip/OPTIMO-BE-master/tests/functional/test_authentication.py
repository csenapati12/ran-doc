from flask import url_for
from flask_jwt_extended.utils import create_access_token


def _register_user(testapp, **kwargs):
    return testapp.post_json(
        url_for("user_views.register_user"),
        {"name": "mo", "email": "mo@mo.mo", "password": "momo"},
        **kwargs
    )


class TestAuthenticate:
    def test_register_user(self, testapp):
        resp = _register_user(testapp)
        assert resp.status_code == 200
        assert resp.json["access_token"]

    def test_user_login_with_valid_credentials(self, testapp):
        _register_user(testapp)

        resp = testapp.post_json(
            url_for("user_views.login_user"),
            {"userName": "mo", "password": "momo"},
        )

        assert resp.status_code == 200

    def test_user_login_with_invalid_credentials(self, testapp):
        _register_user(testapp)

        resp = testapp.post_json(
            url_for("user_views.login_user"),
            {"userName": "mo", "password": "mo"},
            expect_errors=True,
        )

        assert resp.status_code == 400
