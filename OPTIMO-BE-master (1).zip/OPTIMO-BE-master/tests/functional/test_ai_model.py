from flask import url_for
from optimo.models.models import AIModel
import os
import sys
from optimo.settings import Config

DATAPATH = Config.DATA_PATH


def _save_AImodel():
    model = AIModel(
        model_name="testModel1",
        video_id=1,
        video_name="testVideo",
        date_created="testDate",
        shortest_task=1,
        unique_labels="testLabel",
    )
    model.save()


def _save_folder_AImodel():
    modelPath = os.path.abspath(
        os.path.join(os.path.join(DATAPATH, "trained_models"), str(sys.maxsize))
    )
    os.mkdir(modelPath)


class TestAIModel:
    def test_get_model(self, testapp):
        _save_AImodel()

        resp = testapp.get(
            url_for("ai_model_views.getModels"),
        )
        contents = resp.json

        assert resp.status_code == 200
        assert len(contents) == 1
        assert contents[0]["modelName"] == "testModel1"
        assert contents[0]["modelID"] == 1
        assert contents[0]["videoName"] == "testVideo"
        assert contents[0]["videoID"] == 1
        assert contents[0]["dateCreated"] == "testDate"
        assert contents[0]["uniqueLabels"] == "testLabel"

    def test_delete_model(self, testapp):
        _save_AImodel()
        _save_folder_AImodel()

        querriedModel = AIModel.query.filter_by(model_id=1).first()
        querriedModel.update(model_id=sys.maxsize)
        resp = testapp.delete(
            url_for("ai_model_views.deleteModel", modelId=sys.maxsize),
        )
        models_list = AIModel.query.all()

        assert resp.status_code == 200
        assert len(models_list) == 0

    def test_update_model(seldf, testapp):
        _save_AImodel()

        resp = testapp.put(
            url_for("ai_model_views.editModelName", modelId=1, modelName="testModel2"),
        )
        querriedModel = AIModel.query.filter_by(model_id=1).first()

        assert resp.status_code == 200
        assert querriedModel.model_name == "testModel2"

    def test_check_model_name(self, testapp):
        _save_AImodel()

        resp = testapp.get(
            url_for("ai_model_views.checkModelNames", modelName="testModel2"),
        )

        assert resp.status_code == 200

    def test_model_count(self, testapp):
        _save_AImodel()

        resp = testapp.get(
            url_for("ai_model_views.get_model_number"),
        )

        content = resp.json

        assert content["modelNumber"] == 1
