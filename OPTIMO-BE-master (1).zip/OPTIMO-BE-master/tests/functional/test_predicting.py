from flask import url_for
import cv2
import os
import time
import shutil
from optimo.settings import Config
from optimo.models.models import Video, Annotation

DATAPATH = Config.DATA_PATH
originalVideosPath = os.path.abspath(os.path.join(DATAPATH, "original_videos"))
currentVideoName = os.path.abspath(os.path.join(originalVideosPath, "testVideo.mp4"))
models_path = os.path.abspath(
        os.path.join(os.path.join(DATAPATH, "trained_models"), str(1))
        )

def _save_dummy_video():
    video = Video(
        record_time="7-28-2021-16:42:26",
        stop_time="7-28-2021-16:42:36",
        fps=29,
        video_name="testVideo.mp4",
        anno_sign=0,
        user_id=1,
    )
    video.save()
    video = cv2.VideoCapture(0)
    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    writer = cv2.VideoWriter(
        currentVideoName, cv2.VideoWriter_fourcc(*"mp4v"), 20, (width, height)
    )
    t_end = time.time() + 10
    while time.time() < t_end:
        ret, frame = video.read()
        writer.write(frame)
        cv2.imshow("frame", frame)
    video.release()
    writer.release()
    cv2.destroyAllWindows()

def _save_annotation(testapp, **kwargs):
    _save_dummy_video()
    testapp.post_json(
        url_for("annotation_views.saveAnnoInfo"),
        {
            "annoInfo": [
                {
                    "annoBatch": 1,
                    "annoID": 1,
                    "endTime": "00:00:03.50",
                    "startTime": "00:00:00.00",
                    "task": "testTask1",
                    "videoID": 1,
                    "left": "0px",
                    "width": "68.4px",
                },
                {
                    "annoBatch": 1,
                    "annoID": 1,
                    "endTime": "00:00:07.39",
                    "startTime": "00:00:03.79",
                    "task": "testTask2",
                    "videoID": 1,
                    "left": "0px",
                    "width": "68.4px",
                }
            ],
            "saveAs": True,
        },
        **kwargs
    )
def _training(testapp, **kwargs):
    _save_annotation(testapp)
    testapp.post_json(
        url_for("training_views.train_process"),
        {
            "video_id": [1],
            "annotationBatchId": [1],
            "model": "testModel"
        },
        **kwargs
    )

class TestPredictingService:
    def test_predict(self, testapp):
        _training(testapp)
        resp = testapp.post_json(
        url_for("predicting_views.predict_process"),
        {
            "videoID": 1,
            "modelID": 1
        }
        )
        annotation_list = Annotation.query.filter_by(video_id=1).all()
        shutil.rmtree(models_path)
        os.remove(currentVideoName)

        assert resp.status_code == 200
        assert len(annotation_list) > 2

