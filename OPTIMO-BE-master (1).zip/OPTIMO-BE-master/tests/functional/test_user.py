from flask import url_for
from optimo.models.models import User


def _save_user(testapp):
    return testapp.post_json(
        url_for("user_views.register_user"),
        {"name": "momo", "password": "momo", "email": "momo@momo"},
    )


class TestUserService:
    def test_get_user(self, testapp):
        # arrange
        access_token = _save_user(testapp).json
        headers = {"Authorization": "Bearer {}".format(access_token["access_token"])}

        # act
        resp = testapp.get(
            url_for(
                "user_views.get_user",
            ),
            headers=headers,
        )

        # assert
        assert resp.status_code == 200

    def test_user_count(self, testapp):
        # arrange
        _save_user(testapp)

        # act
        resp = testapp.get(
            url_for("user_views.get_user_number"),
        )
        contents = resp.json

        # assert
        assert resp.status_code == 200
        assert contents["userNumber"] == 1

    def test_delete_user(self, testapp):
        # arrange
        _save_user(testapp)

        # act
        resp = testapp.delete(
            url_for("user_views.delete_user", userID=1),
        )
        user = User.query.filter_by(user_id=1).first()

        # assert
        assert resp.status_code == 200
        assert user.is_deleted == True
