class TestTrainingService:
    def test_train():
        """TODO Add logic here"""
