import os
from optimo.settings import Config
from optimo.libs.predicting_manager import PredictingManager

DATAPATH = Config.DATA_PATH

class TestPredictingManager:
    def test_predicting_manager(self, testapp):
        input_video_path = os.path.abspath(
            os.path.join(os.path.join(DATAPATH, "original_videos"), "testVideo.mp4")
        )
        models_path = os.path.abspath(
            os.path.join(os.path.join(DATAPATH, "trained_models"), str(1))
        )
        dense_net_path = os.path.join(models_path, "denseXgB_model_myLayer.h5")
        xgboost_path = os.path.join(models_path, "recognition_xgboost_prev_frames.joblib")
        classes_path = os.path.join(models_path, "classes.txt")

        predicting_manager = PredictingManager(
            input_video_path=input_video_path,
            dense_net_model_path=dense_net_path,
            xgb_model_path=xgboost_path,
            classesID_path=classes_path,
            min_len=3,
        )

        assert predicting_manager.input_video_path == input_video_path
        assert predicting_manager.dense_net_model_path == dense_net_path
        assert predicting_manager.xgb_model_path == xgboost_path
        assert predicting_manager.classes_id_path == classes_path 
        assert predicting_manager.min_len == 3

