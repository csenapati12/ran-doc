from flask_sqlalchemy import model
import pandas as pd
from optimo.settings import Config
from optimo.views.training_views import DATAPATH
import os
from optimo.libs.training_manager import TrainingManager

DATAPATH = Config.DATA_PATH

class TestTrainingManager():
    def _test_training_manager(testapp):
        input_video_path = os.path.abspath(
            os.path.join(DATAPATH, "original_video"), "testVideo.mp4"
        )
        df = pd.DataFrame(columns=["task", "start_frame", "end_frame", "video"])

        output_folder_path = os.path.abspath(
            os.path.join(DATAPATH, "trained_models"), str(model.model_id)
        )
        trained_model_file_name = os.path.abspath(
            os.path.join(DATAPATH,"trained_model_file_name"), "model"
        )

        training_manager = TrainingManager(
           input_video_paths = input_video_path,
           df_annotation = df,
           output_folder_path = output_folder_path, 
           trained_model_file_name = trained_model_file_name
        )
        

        assert training_manager.input_video_paths == input_video_path
        assert training_manager.df_annotation == df
        assert training_manager.output_folder_path == output_folder_path
        assert training_manager.trained_model_file_name == trained_model_file_name


        
        
        
