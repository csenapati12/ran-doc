import pytest
import datetime as dt

from optimo.models.models import User, AIModel, Annotation, Video


@pytest.mark.usefixtures("db")
class TestUser:
    """User tests."""

    def test_get_by_id(self):
        user = User("testuser", "testuser@email.com", False, "testuser")
        user.save()

        querried_user = User.query.get(user.user_id)
        assert querried_user == user

    def test_password_is_nullable(self):
        user = User("testuser", "testuser@email.com", False)
        user.save()

        assert user.user_pass is None

    def test_check_password(self):
        user = User("testuser", "testuser@email.com", False, "userpass1")
        user.save()

        assert user.check_password("userpass1")
        assert not user.check_password("userpass2")


@pytest.mark.usefixtures("db")
class TestAIModel:
    """AI Model tests."""

    def test_get_by_id(self):
        ai_model = AIModel("testmodel", 1, "testvideo", "time", 5.12, 1)
        ai_model.save()

        querried_ai_model = AIModel.query.get(ai_model.model_id)
        assert querried_ai_model == ai_model


@pytest.mark.usefixtures("db")
class TestAnnotation:
    """Annnotation tests."""

    def test_get_by_id(self):
        annotation = Annotation(1, 1, "time", "time", "testannotation")
        annotation.save()

        querried_annotation = Annotation.query.get(annotation.annotation_id)
        assert querried_annotation == annotation


@pytest.mark.usefixtures("db")
class TestVideo:
    """Video tests."""

    def test_get_by_id(self):
        video = Video("time", "time", 30, "testvideo", 1, 1)
        video.save()

        querried_video = Video.query.get(video.video_id)
        assert querried_video == video
