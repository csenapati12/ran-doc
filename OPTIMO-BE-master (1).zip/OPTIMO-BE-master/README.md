# **OPTIMO Express Backend AI model Test**

The back end server is implemented with Flask Framework

# Key Features

- Video Streaming (streaming live from attached camera device, preview and save original videos)
- Video Management (Display neccessary information about video and handy tools for video management)
- Temporal Annotation (customized tools for video temporal annotation)
- Model Training Feature
- Model Inferencing Feature

# Getting Started

## **1. Clone the project**

```bash
git clone https://github.com/OPTIMO-team/OPTIMO-BE.git
```

## **2. Set up environment (Virtual Environment, Flask Settings, DB migration)**

Open a new terminal window in the OPTIMO-BE folder.

### Build virtual enviroment:

*For Windows:*

```bash
py -m venv env # Only run this if env folder does not exist
.\env\Scripts\activate
pip install -r requirements.txt
```

*For MacOS/Linux:*

```bash
python3 -m venv env # Only run this if env folder does not exist
source env/bin/activate
pip install -r optimo/requirements.txt
```

### Change Flask environment config

*For Windows (PowerShell):*

```bash
$env:FLASK_APP = "main.py"
```

*For MacOS/Linux:*

```bash
export FLASK_APP=main.py
```

### Database migration

```bash
flask db upgrade
```

### Run the application

```bash
flask run
```

# Contributing

## Code Style Guide

We will follow Black Code Style Guide ([here](https://black.readthedocs.io/en/stable/the_black_code_style/current_style.html)). Before publishing code, please run the following command: 

```
python -m black {source_file_or_directory}
```

Or you can use Black to reformat the directory *optimo* by:

```
python -m black {ref_to_optimo_directory}
```

Or with VSCode, you can setup *Format on Save* with Black Formatting Provider.

## Test-Driven Development Approach

We will use Pytest for unit testing and functional testing. The set up will be in conftest.py file in *tests* directory.

Before publishing code, please create a test file for it.

A common command:

```
pytest --disable-warnings
```

To generate the code coverage:

```
pytest --cov-report=html --cov=optimo tests/
```