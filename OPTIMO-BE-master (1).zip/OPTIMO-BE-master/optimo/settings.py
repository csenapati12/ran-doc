"""Application configuration."""
from datetime import timedelta
import os


class Config(object):
    """Base configuration"""

    APP_DIR = os.path.abspath(os.path.dirname(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(APP_DIR, os.pardir))
    DATA_PATH = os.path.abspath(os.path.join(PROJECT_ROOT, "data"))
    DATABASE_PATH = os.path.abspath(os.path.join(PROJECT_ROOT, "sqlitedb"))
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "sqlite:///" + DATABASE_PATH
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = "optimosecretkeykeepitprivate"
    JWT_TOKEN_LOCATION = ["cookies", "headers"]
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=1)
    JWT_COOKIE_SECURE = False
    JWT_COOKIE_CSRF_PROTECT = True
    MAIL_SERVER = "smtp.mailtrap.io"
    MAIL_PORT = 2525
    MAIL_USERNAME = "1b4dda5dc00f16"
    MAIL_PASSWORD = "c4484e39ea334b"
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
    CORS_ORIGIN_WHITELIST = ["http://0.0.0.0:8080", "http://localhost:8080"]
    CORS_HEADERS = "Content-Type"


class ProdConfig(Config):
    """Production configuration."""

    ENV = "prod"
    DEBUG = False


class DevConfig(Config):
    """Development configuration."""

    ENV = "dev"
    DEBUG = True


class TestConfig(Config):
    """Test configuration."""

    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = "sqlite://"
