from ..database import Model, db, Column, relationship
from ..extensions import bcrypt


class User(Model):
    __tablename__ = "user"
    user_id = Column("userID", db.Integer, primary_key=True)
    user_name = Column("userName", db.String(256))
    user_email = Column("email", db.String(256))
    user_pass = Column("userPwd", db.String(256))
    is_admin = Column("isAdmin", db.Integer)
    is_deleted = Column("isDeleted", db.Integer)
    token: str = ""

    def __init__(self, user_name, user_email, is_admin, is_deleted,user_pass=None):
        db.Model.__init__(
            self, user_name=user_name, user_email=user_email, is_admin=is_admin, is_deleted=is_deleted
        )
        if user_pass:
            self.set_password(user_pass)
        else:
            self.user_pass = None

    def set_password(self, password):
        """Set password."""
        self.user_pass = bcrypt.generate_password_hash(password)

    def check_password(self, value):
        """Check password."""
        return bcrypt.check_password_hash(self.user_pass, value)


class Annotation(Model):
    __tablename__ = "annotation"
    annotation_id = Column("annoID", db.Integer, primary_key=True)
    video_id = Column("videoID", db.Integer, db.ForeignKey("video.videoID"))
    video = relationship("Video")
    annotation_batch = Column("annoBatch", db.Integer)
    start_time = Column("startTime", db.String(100))
    end_time = Column("endTime", db.String(100))
    task = Column("task", db.String(100))

    def __init__(self, video_id, annotation_batch, start_time, end_time, task):
        db.Model.__init__(
            self,
            video_id=video_id,
            annotation_batch=annotation_batch,
            start_time=start_time,
            end_time=end_time,
            task=task,
        )


class AIModel(Model):
    __tablename__ = "model"
    model_id = Column("modelID", db.Integer, primary_key=True)
    model_name = Column("modelName", db.String(100))
    video_name = Column("videoName", db.String(100))
    date_created = Column("dateCreated", db.String(100))
    shortest_task = Column("shortestTask", db.Numeric)
    unique_labels = Column("uniqueLabels", db.String(100))
    video_id = Column("videoID", db.Integer, db.ForeignKey("video.videoID"))
    video = relationship("Video")

    def __init__(
        self,
        model_name,
        video_id,
        video_name,
        date_created,
        shortest_task,
        unique_labels,
    ):
        db.Model.__init__(
            self,
            model_name=model_name,
            video_id=video_id,
            video_name=video_name,
            date_created=date_created,
            shortest_task=shortest_task,
            unique_labels=unique_labels,
        )


class Video(Model):
    __tablename__ = "video"
    video_id = Column("videoID", db.Integer, primary_key=True)
    record_time = Column("recordTime", db.String(100))
    stop_time = Column("stopTime", db.String(100))
    fps = Column("fps", db.Integer)
    video_name = Column("videoName", db.String(100))
    anno_sign = Column("annoSign", db.Integer)
    user_id = Column("userID", db.Integer, db.ForeignKey("user.userID"))

    def __init__(self, record_time, stop_time, fps, video_name, anno_sign, user_id):
        db.Model.__init__(
            self,
            record_time=record_time,
            stop_time=stop_time,
            fps=fps,
            video_name=video_name,
            anno_sign=anno_sign,
            user_id=user_id,
        )
