#!/usr/bin/env python
from datetime import datetime
from datetime import timedelta
from datetime import timezone
from flask import Flask
from flask_jwt_extended import (
    get_jwt,
    set_access_cookies,
    create_access_token,
    current_user,
)
from optimo.extensions import db, jwt, bcrypt, migrate, mail, cors
from optimo import views
from optimo.settings import Config
from optimo.models.models import User
from optimo.exceptions import InvalidUsage


"""
    NAME

	    app

    DESCRIPTION

	    Will be used to instantiate an application called app. 
        This class will also instantiate the Flask extensions
        and blueprints that app will use. 
"""


def create_app(config_object=Config):
    """
    The purpose of this function is to instantiate the creation of app.

        Parameters:
            config_object - to configure the object.

        Returns:
            app - holds the application.
    """
    app = Flask(__name__.split(".")[0])
    app.url_map.strict_slashes = False
    app.config.from_object(config_object)
    register_extensions(app)
    register_blueprints(app)
    register_errorhandlers(app)
    register_jwt_settings(app)
    register_after_request_settings(app)
    return app


def register_extensions(app):
    """
    Register Flask extensions.

        Parameters:
            app - to instantiate the Flask extension that the app will use.
    """
    bcrypt.init_app(app)
    db.init_app(app)
    migrate.init_app(app, db, render_as_batch=True)
    jwt.init_app(app)
    mail.init_app(app)


def register_blueprints(app):
    """
    Register Flask blueprints.

        Parameters:
            app - to instantiate the blueprints that the app will use.
    """
    origins = app.config.get("CORS_ORIGIN_WHITELIST", "*")
    cors.init_app(views.training_views.blueprint, origins=origins)
    cors.init_app(views.user_views.blueprint, origins=origins)
    cors.init_app(views.video_handling_views.blueprint, origins=origins)
    cors.init_app(views.predicting_views.blueprint, origins=origins)
    cors.init_app(views.annotation_views.blueprint, origins=origins)
    cors.init_app(views.ai_model_views.blueprint, origins=origins)

    app.register_blueprint(views.training_views.blueprint)
    app.register_blueprint(views.user_views.blueprint)
    app.register_blueprint(views.video_handling_views.blueprint)
    app.register_blueprint(views.predicting_views.blueprint)
    app.register_blueprint(views.annotation_views.blueprint)
    app.register_blueprint(views.ai_model_views.blueprint)


def register_errorhandlers(app):
    def errorhandler(error):
        response = error.to_json()
        response.status_code = error.status_code
        return response

    app.errorhandler(InvalidUsage)(errorhandler)


def register_jwt_settings(app):
    @jwt.user_identity_loader
    def user_identity_lookup(user):
        return user.user_id

    @jwt.user_lookup_loader
    def user_lookup_callback(_jwt_header, jwt_data):
        identity = jwt_data["sub"]
        return User.query.filter_by(user_id=identity).one_or_none()


def register_after_request_settings(app):
    @app.after_request
    def refresh_expiring_jwts(response):
        try:
            exp_timestamp = get_jwt()["exp"]
            now = datetime.now(timezone.utc)
            target_timestamp = datetime.timestamp(now + timedelta(minutes=30))
            if target_timestamp > exp_timestamp:
                if current_user.is_admin == 0:
                    access_token = create_access_token(
                        identity=current_user, additional_claims={"is_admin": False}
                    )
                else:
                    access_token = create_access_token(
                        identity=current_user, additional_claims={"is_admin": True}
                    )
                set_access_cookies(response, access_token)

            return response
        except (RuntimeError, KeyError):
            # Case where there is not a valid JWT. Just return the original respone
            return response
