from flask import Blueprint, request, jsonify
import os
import pandas as pd
from sqlalchemy import func
from datetime import datetime

from ..database import db
from ..models.models import Video, Annotation, AIModel
from ..settings import Config
from ..libs.training_manager import TrainingManager


PROJECT_ROOT = Config.PROJECT_ROOT
DATAPATH = Config.DATA_PATH

blueprint = Blueprint("training_views", __name__)


@blueprint.route("/training", methods=("POST",))
def train_process():
    data = request.get_json()
    video_ids = data["video_id"]
    annotation_batch_ids = data["annotationBatchId"]
    trained_model_file_name = data["model"]

    video_paths = []
    video_names = []
    uniqueLabels_list = []
    df = pd.DataFrame(columns=["task", "start_frame", "end_frame", "video"])

    min_len = float("inf")
    for i in range(len(video_ids)):
        video_id = video_ids[i]
        annotation_batch_id = annotation_batch_ids[i]
        # Obtain data from DataBase
        video = Video.query.filter_by(video_id=video_id).first()
        video_names.append(video.video_name)
        # Input path set
        input_video_path = os.path.abspath(
            os.path.join(os.path.join(DATAPATH, "original_videos"), video.video_name)
        )
        video_paths.append(input_video_path)

        # Obtain data from DataBase
        annotation_list = Annotation.query.filter_by(
            video_id=video_id, annotation_batch=annotation_batch_id
        ).all()

        # Modify annotation data
        df_i, min_len_i, uniqueLabels = modify_annotation_data(annotation_list, video)
        uniqueLabels_list.extend(uniqueLabels)
        df_i["video"] = i
        df = df.append(df_i, ignore_index=True)
        # length in seconds of the shortest task
        min_len = min(min_len, min_len_i)
    now = datetime.now()
    dt_string = now.strftime("%m-%d-%Y-%H:%M:%S")
    uniqueLabels_list = list(set(uniqueLabels_list))
    uniqueLabels_list.sort(key=str.lower)
    model = AIModel(
        model_name=trained_model_file_name,
        video_id=str(video_ids).replace('[','').replace(']','').replace("'",""),
        video_name=str(video_names).replace('[','').replace(']','').replace("'",""),
        date_created=dt_string,
        shortest_task=min_len,
        unique_labels=str(uniqueLabels_list).replace('[','').replace(']','').replace("'",""),
    )
    model.save()

    # Output path set
    output_folder_path = os.path.abspath(
        os.path.join(os.path.join(DATAPATH, "trained_models"), str(model.model_id))
    )
    if not os.path.exists(output_folder_path):
        os.makedirs(output_folder_path)
    training_manager = TrainingManager(
        input_video_paths=video_paths,
        df_annotation=df,
        output_folder_path=output_folder_path,
        trained_model_file_name=trained_model_file_name,
    )
    training_manager.train()
    return jsonify(msg="Success")


# Helper functions


def modify_annotation_data(annotation_list, video):
    """
    This function is used to convert seconds to frames.
    It modifies the format of the df.

    Returns:
            new df, min_length, and a unqiue label.
    """
    new_df = pd.DataFrame(columns=["task", "start_frame", "end_frame"])
    fps_video = video.fps
    min_len = float("inf")

    for annotation in annotation_list:
        task_i = annotation.task
        start_i = pd.Series(pd.to_timedelta([annotation.start_time])).dt.total_seconds()
        start_i = start_i[0] * fps_video
        end_i = pd.Series(pd.to_timedelta([annotation.end_time])).dt.total_seconds()
        end_i = end_i[0] * fps_video
        new_df = new_df.append(
            {"task": task_i, "start_frame": start_i, "end_frame": end_i},
            ignore_index=True,
        )
        min_len = min(min_len, (end_i - start_i))

    min_len = min_len / fps_video
    uniqueLabels = new_df["task"].unique()

    return new_df, min_len, uniqueLabels
