from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    jwt_required,
    create_access_token,
    current_user,
    set_access_cookies,
    unset_jwt_cookies,
)
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func

from optimo.database import db
from optimo.models.models import User
from optimo.utils.decorators import admin_required
from optimo.exceptions import InvalidUsage

blueprint = Blueprint("user_views", __name__)


@blueprint.route("/users/register", methods=("POST",))
def register_user():
    data = request.get_json()
    userName = data["name"]
    password = data["password"]
    userEmail = data["email"]
    try:
        user = User(
            user_name=userName,
            user_email=userEmail,
            user_pass=password,
            is_admin=False,
            is_deleted=False,
        ).save()
        user.token = create_access_token(identity=user)
    except IntegrityError:
        db.session.rollback()
        raise InvalidUsage.user_already_registered()
    return jsonify(access_token=user.token)


@blueprint.route("/users/login", methods=("POST",))
def login_user():
    data = request.get_json()
    userName = data["userName"]
    password = data["password"]
    user = User.query.filter_by(user_name=userName).first()
    if user is not None and user.check_password(password) and not user.is_deleted:
        if user.is_admin == 0:
            user.token = create_access_token(
                identity=user, additional_claims={"is_admin": False}
            )
            response = jsonify({"msg": "login successful"})
            set_access_cookies(response, user.token)
            return jsonify(access_token=user.token)
        else:
            user.token = create_access_token(
                identity=user, additional_claims={"is_admin": True}
            )
            response = jsonify({"msg": "login successful"})
            set_access_cookies(response, user.token)
            return jsonify(access_token=user.token)
    else:
        raise InvalidUsage.user_not_found()


@blueprint.route("/logout", methods=["POST"])
def logout():
    response = jsonify({"msg": "logout successful"})
    unset_jwt_cookies(response)
    return response


@blueprint.route("/users/count", methods=("GET",))
def get_user_number():
    userAmount = db.session.query(func.count(User.user_id)).scalar()
    return {"userNumber": userAmount}


@blueprint.route("/users/user", methods=("GET",))
@jwt_required()
def get_user():
    return jsonify(logged_in_as=current_user.user_name), 200


@blueprint.route("/users", methods=("DELETE",))
@admin_required()
def delete_user():
    user_id = request.args.get("userID")
    user = User.query.filter_by(user_id=user_id).first()
    user.update(is_deleted=True)
    return jsonify(msg="Success")


@blueprint.route("/users/information", methods=("GET",))
@admin_required()
def get_user_information():
    user_id = current_user.user_id
    user_list = User.query.all()

    result = []
    for i in range(len(user_list)):
        if user_list[i].user_id == user_id:
            continue
        row_i = {}
        row_i["userID"] = user_list[i].user_id
        row_i["userName"] = user_list[i].user_name
        row_i["userEmail"] = user_list[i].user_email
        row_i["isAdmin"] = user_list[i].is_admin
        row_i["isDeleted"] = user_list[i].is_deleted

        result.append(row_i)

    result = tuple(result)
    return jsonify(result)


@blueprint.route("/users/update-role", methods=("PUT",))
@admin_required()
def update_user_role():
    user_id = request.args.get("userID")
    user = User.query.filter_by(user_id=user_id).first()
    if user is None:
        raise InvalidUsage.user_not_found()
    if user.is_admin == True:
        raise InvalidUsage.user_already_admined()
    user.update(is_admin=True)
    return jsonify(msg="Success")
