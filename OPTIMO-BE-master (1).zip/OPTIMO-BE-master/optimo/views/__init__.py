from . import training_views
from . import video_handling_views
from . import predicting_views
from . import user_views
from . import annotation_views
from . import ai_model_views
