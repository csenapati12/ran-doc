from flask import Blueprint, request
import os

from flask.json import jsonify
from ..models.models import Video, Annotation, AIModel
from ..settings import Config
from ..libs.predicting_manager import PredictingManager

DATAPATH = Config.DATA_PATH
blueprint = Blueprint("predicting_views", __name__)


@blueprint.route("/predicting", methods=("POST",))
def predict_process():
    predict_info = request.get_json()
    video_id = predict_info["videoID"]
    model_id = predict_info["modelID"]

    # Obtain data from DataBase
    video = Video.query.filter_by(video_id=video_id).first()
    model = AIModel.query.filter_by(model_id=model_id).first()

    # Input path set
    input_video_path = os.path.abspath(
        os.path.join(os.path.join(DATAPATH, "original_videos"), video.video_name)
    )

    models_path = os.path.abspath(
        os.path.join(os.path.join(DATAPATH, "trained_models"), str(model.model_id))
    )
    # dense_net_path = os.path.join(
    #     models_path, model.model_name + "_denseXgB_model_myLayerines.h5"
    # )
    dense_net_path = os.path.join(models_path, "denseXgB_model_myLayer.h5")
    # xgboost_path = os.path.join(
    #     models_path, model.model_name + "_recognition_xgboost_prev_frames.joblib"
    # )
    xgboost_path = os.path.join(models_path, "recognition_xgboost_prev_frames.joblib")
    # classes_path = os.path.join(models_path, model.model_name + "_classes.txt")
    classes_path = os.path.join(models_path, "classes.txt")

    predicting_manager = PredictingManager(
        input_video_path=input_video_path,
        dense_net_model_path=dense_net_path,
        xgb_model_path=xgboost_path,
        classesID_path=classes_path,
        min_len=model.shortest_task,
    )

    out_df = predicting_manager.predict()
    out_df = out_df.values.tolist()

    for a in out_df:
        annot = Annotation(
            video_id=video_id,
            annotation_batch=(-model_id),
            start_time=a[1],
            end_time=a[2],
            task=a[0],
        )
        annot.save()

    video.anno_sign = 1
    video.save()

    return jsonify(msg="Success")
