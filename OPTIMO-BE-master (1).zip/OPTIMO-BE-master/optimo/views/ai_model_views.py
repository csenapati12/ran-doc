from flask import Blueprint, json, request, jsonify
import shutil
import os
from sqlalchemy import func
from flask_sqlalchemy import model

from optimo.database import db
from optimo.models.models import AIModel
from optimo.settings import Config
from optimo.exceptions import InvalidUsage

DATAPATH = Config.DATA_PATH
blueprint = Blueprint("ai_model_views", __name__)


@blueprint.route("/models", methods=("GET",))
def getModels():
    models_list = AIModel.query.all()
    result = []
    for i in range(len(models_list)):
        row_i = {}
        row_i["dateCreated"] = models_list[i].date_created
        row_i["modelID"] = models_list[i].model_id
        row_i["modelName"] = models_list[i].model_name
        row_i["shortestTask"] = str(round(models_list[i].shortest_task, 2))
        row_i["videoID"] = models_list[i].video_id
        row_i["videoName"] = models_list[i].video_name
        row_i["uniqueLabels"] = str(models_list[i].unique_labels)
        result.append(row_i)

    result = tuple(result)
    return jsonify(result)


@blueprint.route("/models", methods=("DELETE",))
def deleteModel():
    model_id = request.args.get("modelId")
    modelPath = os.path.abspath(
        os.path.join(os.path.join(DATAPATH, "trained_models"), str(model_id))
    )
    querriedModel = AIModel.query.filter_by(model_id=model_id).first()

    if querriedModel is not None and os.path.exists(modelPath):
        shutil.rmtree(modelPath)
        querriedModel.delete()
    else:
        raise InvalidUsage.ai_model_not_found()
    return jsonify(msg="success")


@blueprint.route("/models", methods=("PUT",))
def editModelName():
    model_id = request.args.get("modelId")
    new_model_name = request.args.get("modelName")
    querriedModel = AIModel.query.filter_by(model_id=model_id).first()

    if querriedModel is not None:
        querriedModel.model_name = new_model_name
        querriedModel.save()
    else:
        raise InvalidUsage.ai_model_not_found()

    return jsonify(msg="success")


@blueprint.route("/models/verify", methods=("GET",))
def checkModelNames():
    newName = request.args.get("modelName")
    models_list = AIModel.query.all()
    result = []
    for i in range(len(models_list)):
        result.append(models_list[i].model_name)

    if newName in result:
        raise InvalidUsage.ai_model_name_already_existed()
    else:
        return jsonify(msg="Success")


@blueprint.route("/models/count", methods=("GET",))
def get_model_number():
    modelAmount = db.session.query(func.count(AIModel.model_id)).scalar()
    return {"modelNumber": modelAmount}
