from flask_migrate import current
import jwt
from optimo.views.predicting_views import DATAPATH
from flask import Blueprint, Response, request, make_response, jsonify
import os
from shutil import copy2
from flask.helpers import send_from_directory
from flask_apispec import marshal_with
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func
from cv2 import cv2
import os
from flask_jwt_extended import jwt_required, current_user, get_jwt_identity
import base64

from optimo.utils.decorators import admin_required
from optimo.serializers.video_serializer import video_schemas
from optimo.database import db
from optimo.utils.camera_opencv import Camera
from optimo.utils.upload_videos import Upload
from optimo.models.models import Video, Annotation
from optimo.settings import Config
from optimo.exceptions import InvalidUsage


global indexAddCounter
global currentVideoName
global currentFPS
indexAddCounter = False
currentVideoName = ""
currentFPS = 0

PROJECT_ROOT = Config.PROJECT_ROOT
DATAPATH = Config.DATA_PATH
temporaryVideosPath = os.path.abspath(os.path.join(DATAPATH, "temporary_videos"))
originalVideosPath = os.path.abspath(os.path.join(DATAPATH, "original_videos"))
videoImagesPath = os.path.abspath(os.path.join(DATAPATH, "video_image"))

blueprint = Blueprint("video_handling_views", __name__)


@blueprint.route("/videos/streaming", methods=("GET",))
def streaming():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(gen(Camera()), mimetype="multipart/x-mixed-replace; boundary=frame")


@blueprint.route("/videos/records/start", methods=("POST",))
def startRecord():
    global indexAddCounter
    global currentVideoName
    content = request.get_json()
    indexAddCounter = content["startRecord"]
    currentVideoName = content["videoName"]
    currentVideoName = os.path.abspath(
        os.path.join(temporaryVideosPath, currentVideoName)
    )
    return jsonify(msg="Success")


@blueprint.route("/videos/records/stop", methods=("POST",))
def stopRecord():
    global indexAddCounter
    content = request.get_json()
    indexAddCounter = content["stopRecord"]
    return jsonify(msg="Success")


@blueprint.route(
    "/videos/video",
    methods=[
        "POST",
    ],
)
@jwt_required()
def saveVideoInfo():
    global currentFPS
    contents = request.get_json()
    for content in contents:
        startTime = content["start"]
        endTime = content["end"]
        videoName = content["videoName"]
        fps = currentFPS
        annoSign = 0
        if fps == 0:
            raise InvalidUsage.stream_video_bad_request()
        else:
            if _isVideoExisted(videoName):
                raise InvalidUsage.video_name_already_existed()
            video = Video(
                record_time=startTime,
                stop_time=endTime,
                fps=fps,
                video_name=videoName,
                anno_sign=annoSign,
                user_id=current_user.user_id,
            )
            # copy the video from temporary_videos folder to original_videos folder
            from_path = os.path.abspath(os.path.join(temporaryVideosPath, videoName))
            to_path = os.path.abspath(os.path.join(originalVideosPath, videoName))
            copy2(from_path, to_path)
            os.remove(from_path)
            video.save()
    return jsonify(msg="Success")


@blueprint.route(
    "/videos/video/upload",
    methods=[
        "POST",
    ],
)
@jwt_required()
def uploadVideo():
    file = request.files["file"]
    if not file:
        raise InvalidUsage.upload_video_file_bad_request()
    if _isVideoExisted(file.filename):
        raise InvalidUsage.video_name_already_existed()
    uploader = Upload(
        file=file, upload_path=originalVideosPath, user_id=current_user.user_id
    )
    return uploader.upload_file()


@blueprint.route("/videos/count", methods=("GET",))
def getVideoCount():
    videoAmount = db.session.query(func.count(Video.video_id)).scalar()
    return {"videoNumber": videoAmount}


@blueprint.route("/videos/video-signs", methods=("GET",))
def getVideoSigns():
    oriVideoAmount = Video.query.filter_by(anno_sign=0).count()
    annoVideoAmount = Video.query.filter_by(anno_sign=1).count()
    inferVideoAmount = Video.query.filter_by(anno_sign=-1).count()
    return {
        "oriVideoNumber": oriVideoAmount,
        "annoVideoNumber": annoVideoAmount,
        "inferVideoNumber": inferVideoAmount,
    }


@blueprint.route("/videos/video/<path:file_name>", methods=("GET",))
def showVideo(file_name):
    try:
        return send_from_directory(
            originalVideosPath, path=file_name, as_attachment=True
        )
    except FileNotFoundError:
        os.abort(404)


@blueprint.route("/videos", methods=("GET",))
@marshal_with(video_schemas)
@jwt_required()
def getVideoList():
    videoType = request.args.get("annoSign")
    videoList = Video.query.filter_by(
        anno_sign=videoType, user_id=current_user.user_id
    ).all()
    return videoList


@blueprint.route("/videos", methods=("DELETE",))
def delVideo():
    videoName = request.args.get("videoName")
    videoPath = os.path.abspath(os.path.join(originalVideosPath, videoName))
    querriedVideo = Video.query.filter_by(video_name=videoName).first()
    video_id = querriedVideo.video_id
    annots = Annotation.query.filter_by(video_id=video_id).all()

    if querriedVideo is not None and os.path.exists(videoPath):
        os.remove(videoPath)
        querriedVideo.delete()
    else:
        raise InvalidUsage.video_not_found()

    if annots is not None:
        for annot in annots:
            annot.delete()

    return jsonify(msg="Success")


@blueprint.route("/backgroundImage", methods=("GET",))
def getBackgroundImage():
    videoName = request.args.get("videoName")
    querriedVideo = Video.query.filter_by(video_name=videoName).first()
    backgrounImageName = str(querriedVideo.video_id) + ".jpeg"
    backgroundImagePath = os.path.abspath(
        os.path.join(videoImagesPath, backgrounImageName)
    )
    videoPath = os.path.abspath(os.path.join(originalVideosPath, videoName))

    if not os.path.exists(backgroundImagePath):
        vidcap = cv2.VideoCapture(videoPath)
        _, img = vidcap.read()
        cv2.imwrite(backgroundImagePath, img)

    backgroundImage = open(backgroundImagePath, "rb")
    backgroundImage64Encode = base64.b64encode(backgroundImage.read())
    res = "data:image/jpeg;base64," + str(backgroundImage64Encode.decode("utf-8"))
    return res


# ______Helper functions________
def _isVideoExisted(videoName):
    """
    This function is used to check if there is
    an existing video at the videoName.
    """
    querriedVideoList = Video.query.filter_by(video_name=videoName).all()
    if querriedVideoList:
        return True
    else:
        return False


def gen(camera):
    """
    The purpose of this function is to create a
    video streaming generator.
    """
    cnt = 0
    setupOutput = False
    out_started = False
    global indexAddCounter
    global currentVideoName
    global currentFPS

    while True:
        cnt += 1
        frame = camera.get_frame()
        if indexAddCounter:
            if not setupOutput:
                fourcc = cv2.VideoWriter_fourcc(*"MJPG")
                currentFPS = camera.video_fps
                try:
                    out = cv2.VideoWriter(
                        currentVideoName,
                        cv2.VideoWriter_fourcc("H", "2", "6", "4"),
                        camera.video_fps,
                        camera.video_size,
                    )
                except:
                    out = cv2.VideoWriter(
                        currentVideoName,
                        cv2.VideoWriter_fourcc(*"mp4v"),
                        camera.video_fps,
                        camera.video_size,
                    )
                setupOutput = True
                out_started = True
                first_img_path = os.path.join(
                    DATAPATH,
                    "Video_image",
                    os.path.basename(currentVideoName)[:-4] + ".png",
                )
                # Save the first frame as the image to show in the annotation page
                cv2.imwrite(first_img_path, frame)
            out.write(frame)
        else:
            setupOutput = False
            if out_started:
                out.release()

        frame = cv2.imencode(".jpg", frame)[1].tobytes()
        yield (b"--frame\r\n" b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
