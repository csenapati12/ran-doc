from flask import Blueprint, request, jsonify
from sqlalchemy import desc
from sqlalchemy import func
import pandas as pd

from ..models.models import Video, Annotation
from ..settings import Config
from ..database import db

PROJECT_ROOT = Config.PROJECT_ROOT
DATAPATH = Config.DATA_PATH
blueprint = Blueprint("annotation_views", __name__)


# Save annotation information
@blueprint.route("/annotations/annotation", methods=("POST",))
def saveAnnoInfo():
    # Request info from the FE
    req_info = request.get_json()
    anno_info = req_info["annoInfo"]
    save_as_new = req_info["saveAs"]

    # Obtain max annotation batch from DB
    try:
        annotation_batch_id = anno_info[0]["annoBatch"]
    except:
        annotation_batch_id = 1
    video_id = anno_info[0]["videoID"]
    annotation_list = (
        Annotation.query.filter_by(video_id=video_id)
        .order_by(desc(Annotation.annotation_batch))
        .limit(1)
        .all()
    )
    if len(annotation_list) == 0:
        annotation_batch_id_max = 0
    else:
        annotation_batch_id_max = annotation_list[0].annotation_batch

    # Delete previous annotation batch if required
    if not save_as_new:
        Annotation.query.filter_by(
            video_id=video_id, annotation_batch=annotation_batch_id
        ).delete()
    else:
        # Update annoBatch value
        annotation_batch_id = max(annotation_batch_id_max, 0) + 1

    # Insert new annotation data in the DB
    for i in range(len(anno_info)):
        annot = Annotation(
            video_id=video_id,
            annotation_batch=annotation_batch_id,
            start_time=anno_info[i]["startTime"],
            end_time=anno_info[i]["endTime"],
            task=anno_info[i]["task"],
        )
        annot.save()

    # Update video annotation sign
    video = Video.query.filter_by(video_id=video_id).first()
    video.anno_sign = 1
    video.save()

    return {"anno_batch": annotation_batch_id}


@blueprint.route("/annotations/annotation-boxes", methods=("GET",))
def getAnnoBoxes():
    video_id = request.args.get("videoID")
    batch_id = request.args.get("batch_id")

    # Get annotation_batch_id_max
    if batch_id == -1:
        annotation_list = (
            Annotation.query.filter_by(video_id=video_id)
            .order_by(desc(Annotation.annotation_batch))
            .limit(1)
            .all()
        )
        annotation_batch_id_max = annotation_list[0].annotation_batch
    else:
        annotation_batch_id_max = batch_id

    # Collect the most recent annotation
    annotation_list = Annotation.query.filter_by(
        video_id=video_id, annotation_batch=annotation_batch_id_max
    ).all()
    result = []
    for i in range(len(annotation_list)):
        row_i = {}
        row_i["startTime"] = annotation_list[i].start_time
        row_i["endTime"] = annotation_list[i].end_time
        row_i["task"] = annotation_list[i].task
        row_i["annoBatch"] = annotation_list[i].annotation_batch
        row_i["videoID"] = annotation_list[i].video_id
        row_i["annoID"] = annotation_list[i].annotation_id
        result.append(row_i)

    result = tuple(result)
    return jsonify(result)


@blueprint.route("/annotations/annotation-batches", methods=("GET",))
def getAnnotationBatches():
    video_id = request.args.get("video_id")

    batches = (
        Annotation.query.filter_by(video_id=video_id)
        .distinct("annotation_batch")
        .with_entities(Annotation.annotation_batch)
        .all()
    )
    batches = [item for sublist in batches for item in sublist]
    batches.sort()
    result = []

    for batch in batches:
        result_i = {}
        if batch > 0:
            name = "Version " + str(batch)
            result_i["id"] = batch
            result_i["name"] = name
        else:
            name = "AI assisted - Model " + str(-batch)
            result_i["id"] = batch
            result_i["name"] = name
        result.append(result_i)

    result = tuple(result)
    return jsonify(result)


@blueprint.route("/annotations", methods=("DELETE",))
def deleteAnnotationBatches():
    video_id = request.args.get("videoID")
    batch_id = request.args.get("batch_id")
    annots = Annotation.query.filter_by(
        video_id=video_id, annotation_batch=batch_id
    ).all()
    for annot in annots:
        annot.delete()
    return jsonify(msg="Success")


@blueprint.route("/annotations/unique-label-names", methods=("POST",))
def getUniqueLabelNames():
    data = request.get_json()
    video_ids = data["video_id"]
    annot_ids = data["annotationBatchId"]
    row_i = {}
    for i in range(len(video_ids)):
        annots = (
            Annotation.query.filter_by(
                video_id=video_ids[i], annotation_batch=annot_ids[i]
            ).all())
  
        for i in range(len(annots)):
            
            start_time = pd.Series(pd.to_timedelta([annots[i].start_time])).dt.total_seconds()
            end_time = pd.Series(pd.to_timedelta([annots[i].end_time])).dt.total_seconds()
            duration = round(end_time[0]-start_time[0],2)*1
            task = annots[i].task
            if task in row_i:
                row_i[str(task)]+=duration
            else:
                row_i[str(task)]=duration


    percent = [round(x/sum(row_i.values()),2) for x in row_i.values()]
    unique_labels = list(row_i.keys())
    unique_labels.sort()
    percent = [percent[list(row_i.keys()).index(label)] for label in unique_labels]
    result = []
    for i in range(len(unique_labels)):
        result_i = {}
        result_i["label"] = unique_labels[i]
        result_i["percent"] = percent[i]
        result.append(result_i)

    result = tuple(result)
    return jsonify(result)


@blueprint.route("/annotations/count", methods=("GET",))
def getAnnotationsCount():
    annoAmount = db.session.query(func.count(Annotation.annotation_id)).scalar()
    return {"annoNumber": annoAmount}
