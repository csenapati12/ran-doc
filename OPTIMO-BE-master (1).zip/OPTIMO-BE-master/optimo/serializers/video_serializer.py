from marshmallow import Schema, fields, pre_load, post_dump


class VideoSchema(Schema):
    video_id = fields.Int()
    record_time = fields.Str()
    stop_time = fields.Str()
    fps = fields.Int()
    video_name = fields.Str()
    anno_sign = fields.Int()
    video = fields.Nested("self", exclude=("video",), default=True, load_only=True)

    class Meta:
        strict = True


video_schema = VideoSchema()
video_schemas = VideoSchema(many=True)
