import os
from cv2 import cv2
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier
from joblib import dump
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
from tensorflow.keras.preprocessing.image import ImageDataGenerator, img_to_array
from tensorflow.keras.applications import DenseNet121
from tensorflow.keras.optimizers import Adam
import random
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, BatchNormalization
from tensorflow.keras.layers import Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import ModelCheckpoint, ReduceLROnPlateau
import numpy as np


class TrainingManager(object):
    """
     NAME

            TrainingManager

    DESCRIPTION

            TrainingManager is an object class that is apart of OPTIMO
        owned by Foxconn. It will take in a video, manipulate it and
        produced a trained video.

            It aims to provide users with helpful, trained data, that
        will assist the user with a plethora of tasks.

    TODO

        Refactoring for testing.

    NOTES

        The TrainingManager object handles training process. This class is hard to
        test unless get broken down to smaller processes. If you need to add base
        models for scaling, consider create a separate object.
    """

    def __init__(
        self,
        input_video_paths,
        df_annotation,
        output_folder_path,
        trained_model_file_name,
    ):
        """
        The function below is constructor for the TrainingManager class.

        Attributes
        ___________
        self : used to pass the necessary variables.
        input_video_paths : holds path for input videos.
        df_annotation : keeps track of annotated data.
        output_folder_path : holds path for output videos.
        trained_model_file_name : holds trained file name.
        """

        self.input_video_paths = input_video_paths
        self.df_annotation = df_annotation
        self.output_folder_path = output_folder_path
        self.trained_model_file_name = trained_model_file_name

    def train(self):

        """
        This function is where the training takes place.
        The model to be trained is composed by a DenseNet121 model and
        an XGBoost model. Thanks to the XGBoost model, we are able to use
        the last 7 frames for prediction.

            Parameters:
                        self: used to pass the necessary variables:
                        input_video_paths, df_annotation, output_folder_path,
                        trained_model_file_name.

            Returns:
                        This function doesn't return anything, but creates a new
                        folder inside "trained_models" folder. The name of this
                        folder is the ID number of the model. Inside this folder,
                        there are 3 files that contain the trained model:
                        classes.txt, denseXgB_model_myLayer.h5,
                        recognition_xgboost_prev_frames.joblib
        """

        # Create taskID column: each task name will be assigned a number

        le = LabelEncoder()
        self.df_annotation["taskID"] = le.fit_transform(self.df_annotation["task"])
        classesID = list(le.classes_)

        # Create a text file with the ordered classes so that we can decode it afterwards
        with open(
            os.path.join(
                self.output_folder_path,
                # str(self.trained_model_file_name) + "_classes.txt",
                "classes.txt",
            ),
            "w",
        ) as output:
            for row in classesID:
                output.write(str(row) + "\n")

        data = []
        labels = []

        for i in range(len(self.input_video_paths)):
            # Select the corresponding annotation for each video
            df_annotation_i = self.df_annotation[self.df_annotation["video"] == i]

            # Open video
            vid = cv2.VideoCapture(self.input_video_paths[i])
            if not vid.isOpened():
                raise IOError("Couldn't open webcam or video")

            # Get data ready for training
            cnt = 0  # Start counter

            while vid.isOpened():
                return_value, frame = vid.read()
                if not return_value:
                    break
                if cnt > max(df_annotation_i["end_frame"]):
                    break

                l = df_annotation_i[
                    (df_annotation_i["start_frame"] <= cnt)
                    & (df_annotation_i["end_frame"] >= cnt)
                ]["taskID"]

                if l.shape[0] == 1:
                    l = l.iloc[0]
                    l = int(l)
                    labels.append(l)
                    frame1 = frame.copy()
                    image = cv2.resize(frame, (128, 128))
                    image = img_to_array(image)
                    data.append(image)
                cnt += 1

            vid.release()

        # Adjust the data array
        data = np.array(data, dtype="float32") / 255.0

        # Copy of the lables for XGB training
        ytrainNum = labels

        # Initialize random seed
        random.seed(42)

        # Modify labels format to fit in DenseNet
        labels = np.array(labels)
        mlb = LabelBinarizer()
        labels = mlb.fit_transform(labels)
        label_order = mlb.classes_

        # Train_test_split for DenseNet training
        (xtrain, xtest, ytrain, ytest) = train_test_split(
            data, labels, stratify=labels, test_size=0.2, random_state=42
        )  # We don't really need this line
        ###########################################
        #######       DenseNet Model        #######
        ###########################################

        # from tensorflow.keras.models import Model

        model_d = DenseNet121(
            weights="imagenet", include_top=False, input_shape=(128, 128, 3)
        )

        x = model_d.output

        x = GlobalAveragePooling2D()(x)
        x = BatchNormalization()(x)
        x = Dropout(0.5)(x)
        x = Dense(1024, activation="relu", name="my_dense")(x)
        x = Dense(512, activation="relu")(x)
        x = BatchNormalization()(x)
        x = Dropout(0.5)(x)

        # preds=Dense(8,activation='softmax')(x) #FC-layer
        if len(classesID) == 2:
            preds = Dense(1, activation="softmax")(x)  # FC-layer
        else:
            preds = Dense(len(classesID), activation="softmax")(x)  # FC-layer

        # model=Model(inputs=base_model.input,outputs=preds)
        model1 = Model(inputs=model_d.input, outputs=preds)
        # model1.summary()

        for layer in model1.layers[:-8]:
            layer.trainable = False

        for layer in model1.layers[-8:]:
            layer.trainable = True

        model1.compile(
            optimizer=Adam(learning_rate=0.008),
            loss="categorical_crossentropy",
            metrics=["accuracy"],
        )
        # model1.summary()

        layer_name = "my_dense"
        intermediate_layer_model = Model(
            inputs=model1.input, outputs=model1.get_layer(layer_name).output
        )

        # intermediate_layer_model.summary()

        # anne = ReduceLROnPlateau(monitor='val_acc', factor=0.5, patience=5, verbose=1, min_lr=1e-3)
        anne = ReduceLROnPlateau(
            monitor="val_accuracy", factor=0.7, patience=5, verbose=1, min_lr=1e-7
        )
        checkpoint = ModelCheckpoint(
            os.path.join(
                self.output_folder_path, str(self.trained_model_file_name) + "_model.h5"
            ),
            verbose=1,
            save_best_only=True,
        )

        # datagen = ImageDataGenerator(zoom_range = 0.2, horizontal_flip=True, shear_range=0.2)
        datagen = ImageDataGenerator(
            zoom_range=0.2, horizontal_flip=False, shear_range=0.2, rotation_range=15
        )

        datagen.fit(xtrain)
        # Fits-the-model
        batchSize = 64
        history = model1.fit(
            datagen.flow(xtrain, ytrain, batch_size=batchSize),
            steps_per_epoch=xtrain.shape[0] // batchSize,
            epochs=30,
            verbose=2,
            callbacks=[anne, checkpoint],
            validation_data=(xtest, ytest),
        )

        # model1.save(
        #     os.path.join(
        #         self.output_folder_path,
        #         str(self.trained_model_file_name) + "_denseXgB_model_ines.h5",
        #     )
        # )
        intermediate_layer_model.save(
            os.path.join(
                self.output_folder_path,
                # str(self.trained_model_file_name) + "_denseXgB_model_myLayerines.h5",
                "denseXgB_model_myLayer.h5",
            )
        )

        ###########################################
        #######        XGBoost Model        #######
        ###########################################

        intermediate_output = intermediate_layer_model.predict(data)

        hist_count = 7  # take into account the previous 7 frames

        training_data_temporal = []

        for frame in range(len(intermediate_output)):
            # df = data[data['frame']==(frame+1)].iloc[0,2:].astype(int).tolist() # Frame starts at 1
            df = intermediate_output[frame]

            if frame == 0:

                # Start the rowlist
                row_data = (
                    np.zeros(hist_count * len(intermediate_output[0]))
                    .astype(int)
                    .tolist()
                )
                row_data[-(len(intermediate_output[0])) :] = df
            else:
                row_data = row_data[len(intermediate_output[0]) :]
                row_data.extend(df)
            assert len(row_data) == (hist_count * len(intermediate_output[0]))
            training_data_temporal.append(row_data)

        training_data_temporal = np.array(training_data_temporal)

        xgbmodel = XGBClassifier()

        xgbmodel.fit(training_data_temporal, ytrainNum)
        dump(
            xgbmodel,
            os.path.join(
                self.output_folder_path,
                # str(self.trained_model_file_name)
                # + "_recognition_xgboost_prev_frames.joblib",
                "recognition_xgboost_prev_frames.joblib",
            ),
        )
        deletion_path = os.path.join(self.output_folder_path, str(self.trained_model_file_name) + "_model.h5")
        print("deletion_path: ", deletion_path)
        if os.path.exists(deletion_path):
            os.remove(deletion_path)
        return
