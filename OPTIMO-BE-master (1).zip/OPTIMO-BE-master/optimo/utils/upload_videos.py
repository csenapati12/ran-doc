from flask import Blueprint, Response, request
import os
import pandas as pd
from datetime import datetime
import cv2

from sqlalchemy.exc import IntegrityError
from sqlalchemy.sql.functions import user
from ..models.models import Video

# TODO: Remove DB access for Upload class or Separate DB calls from DB access class
class Upload:
    def __init__(self, file, upload_path, user_id):
        self.upload_path = upload_path
        self.file = file
        self.user_id = user_id

    def upload_file(self):
        """save files and write DB"""
        videoName = self.file.filename
        extension = videoName.split(".")[-1]
        if extension == "mp4" or extension == "avi":
            self.file.save(os.path.join(self.upload_path, videoName))
            now = datetime.now()
            dt_string = now.strftime("%m-%d-%Y-%H:%M:%S")
            startTime = dt_string
            endTime = dt_string

            # Open video
            vid = cv2.VideoCapture(os.path.join(self.upload_path, videoName))
            if not vid.isOpened():
                raise IOError("Couldn't open webcam or video")

            # Save first frame
            img_saved = False
            first_img_path = os.path.join(
                self.upload_path, "Video_image", videoName[:-4] + ".png"
            )
            while not img_saved:
                ret, frame = vid.read()
                if ret == True:
                    cv2.imwrite(first_img_path, frame)
                    img_saved = True

            # Obtain FPS
            video_fps = vid.get(cv2.CAP_PROP_FPS)
            vid.release()

            fps = video_fps
            annoSign = 0
            try:
                video = Video(
                    record_time=startTime,
                    stop_time=endTime,
                    fps=fps,
                    video_name=videoName,
                    anno_sign=annoSign,
                    user_id=self.user_id,
                )
                video.save()
                result = {"status": 200, "videoID": video.video_id}
                return result
            except IntegrityError:
                return {"status": 500}
        else:
            return {"status": "extension error"}
