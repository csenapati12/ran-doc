from optimo.models.models import AIModel
from flask import jsonify


def template(data, code=500):
    return {"message": {"errors": {"body": data}}, "status_code": code}


USER_NOT_FOUND = template(["User not found"], code=404)
USER_ALREADY_REGISTERED = template(["User already registered"], code=422)
USER_ALREADY_ADMIN = template(["This user is already admin"], code=422)
UNKNOWN_ERROR = template([], code=500)
STREAM_VIDEO_BAD_REQUEST = template(["Stream video not found"], code=400)
VIDEO_NAME_ALREADY_EXISTED = template(["Video name already existed"], code=422)
UPLOAD_VIDEO_FILE_BAD_REQUEST = template(
    ["Unable to receive video from client"], code=400
)
VIDEO_NOT_FOUND = template(["Video not found"], code=404)
AI_MODEL_NOT_FOUND = template(["AI model not found"], code=404)
AI_MODEL_NAME_ALREADY_EXISTED = template(
    ["This model name is already in use"], code=422
)


class InvalidUsage(Exception):
    status_code = 500

    def __init__(self, message, status_code=None, payload=None):
        Exception.__init__(self)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload

    def to_json(self):
        rv = self.message
        return jsonify(rv)

    @classmethod
    def user_not_found(cls):
        return cls(**USER_NOT_FOUND)

    @classmethod
    def user_already_admined(cls):
        return cls(**USER_ALREADY_ADMIN)
        
    @classmethod
    def user_already_registered(cls):
        return cls(**USER_ALREADY_REGISTERED)

    @classmethod
    def unknown_error(cls):
        return cls(**UNKNOWN_ERROR)

    @classmethod
    def video_not_found(cls):
        return cls(**VIDEO_NOT_FOUND)

    @classmethod
    def stream_video_bad_request(cls):
        return cls(**STREAM_VIDEO_BAD_REQUEST)

    @classmethod
    def video_name_already_existed(cls):
        return cls(**VIDEO_NAME_ALREADY_EXISTED)

    @classmethod
    def upload_video_file_bad_request(cls):
        return cls(**UPLOAD_VIDEO_FILE_BAD_REQUEST)

    @classmethod
    def ai_model_not_found(cls):
        return cls(**AI_MODEL_NOT_FOUND)

    @classmethod
    def ai_model_name_already_existed(cls):
        return cls(**AI_MODEL_NAME_ALREADY_EXISTED)
